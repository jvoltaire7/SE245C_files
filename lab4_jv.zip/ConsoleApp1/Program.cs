﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using ConsoleApp1;

namespace Junior_Class_Lab4

{
    
    //=========================================================================================


    class Program
    {
       
        public class Person 
        {
            private string fname;
            private string mname;
            private string lname;
            private string fstreet;
            private string sstreet;
            private string city;
            private string state;
            private string zip;
            private string number;
            private string email;

         




            public string Fname
            {
                get
                {
                    return fname;

                }
                set
                {
                   

                    if (V_list_Collection.Has_info(value) == true)
                    {
                        fname = value;
                    }
                    else
                    {
                        fname = "Wrong F Name Format";
                    }
                }

            }

            public string Mname
            {
                get
                {
                    return mname;

                }
                set
                {
                    if (value == "")
                    {
                        mname = "Either Person Doesn't Have a Middle name/ or They left blank";
                    }

                    else
                    {
                        mname = value;
                    }
                }

            }

            public string Lname
            {
                get
                {
                    return lname;

                }
                set
                {
                    if (V_list_Collection.Has_info(value) == true)
                    {
                        lname = value;
                    }

                    else
                    {
                        lname = "Left Empty- Required / please Add Last Name";
                    }

                }

            }

            public string Fstreet
            {
                get
                {
                    return fstreet;

                }
                set
                {
                    if (V_list_Collection.Has_info(value) == true)
                    {
                        fstreet = value;
                    }

                    else
                    {
                        fstreet = "Invalid Must be filled in";
                    }


                }

            }

            public string Sstreet
            {
                get
                {
                    return sstreet;

                }
                set
                {
                    if (value == "")
                    {
                        sstreet = "Either Person Doesn't Have a Second Address name/ or They left blank";
                    }

                    else
                    {
                        sstreet = value;
                    }

                }

            }

            public string City
            {
                get
                {
                    return city;

                }
                set
                {
                    if (V_list_Collection.Has_info(value) == true)
                    {
                        city = value;
                    }

                    else
                    {
                        city = "Left Empty- Requried/ Please write city";
                    }


                }

            }

            public string State
            {
                get
                {
                    return state;

                }
                set
                {
                    if (V_list_Collection.Has_info(value) == true)
                    {
                        state = value;
                    }

                    else if (V_list_Collection.minimum_requirement(value, 2) == true)
                    {
                        state = "State format is too short/ either include initals or entire state name";
                    }
                    else
                    {
                        state = "left Empty - Required / Please write your state ";
                    }

                }

            }

            public string Zip
            {
                get
                {
                    return zip;

                }
                set

                {
                    if (V_list_Collection.Has_info(value) == true)
                    {
                        zip = value;
                    }
                    else if (V_list_Collection.minimum_requirement(value, 5) == true)
                    {
                        state = "Zip code is too short make it  digits --> 02222";
                    }
                    else
                    {
                        zip = "left Empty - Required / Please write a Zip code";
                    }
                }

            }

            public string Number
            {
                get
                {
                    return number;

                }
                set
                {

                    if (V_list_Collection.valid_number_format(value) == true)
                    {
                        number = value;
                    }

                    else
                    {
                        number = "Either left empty/ or format not good -> 111-111-1111";
                    }



                }

            }

            public string Email
            {
                get
                {
                    return email;

                }
                set
                {
                    if (V_list_Collection.email_comfirm(value))
                    {

                        email = value;
                    }
                    else
                    {
                        email = "either left blank/ or bad email-> example:  junior@gmail.com";
                    }
                }

            }
        }


        static void Main(string[] args)
        {




        

            Person temp = new Person();
            Console.WriteLine("=======================================INFORMATION REGESTRIGAION PROGRAM=======================================");
            Console.WriteLine("\n\n\n");

            //Asking for the information to add
            Console.Write("\t\t Please type in your First Name: ");
            temp.Fname = Console.ReadLine();
            Console.Write("\t\t Please type in your middle name: ");
            temp.Mname = Console.ReadLine();
            Console.Write("\t\t Please Type in your  last name: ");
            temp.Lname = Console.ReadLine();
            Console.Write("\t\t Please Type in your first street Address: ");
            temp.Fstreet = Console.ReadLine();
            Console.Write("\t\t Please Type in your second street Address:");
            temp.Sstreet = Console.ReadLine();
            Console.Write("\t\t Please Type in your city:  ");
            temp.City = Console.ReadLine();
            Console.Write("\t\t Please type in your State:   ");
            temp.State = (Console.ReadLine());          
            Console.Write("\t\t Please Type in your ZIP of your current area:   ");
            temp.Zip = Console.ReadLine();
            Console.Write("\t\t Please Type in a good Cell-Phone number to contact :   ");
            temp.Number = Console.ReadLine();
            Console.Write("\t\t Please Type in an email to best contact you:  ");
            temp.Email = Console.ReadLine();
            Console.WriteLine("\n\n");


            //Information print in the screen
            Console.WriteLine("=======================================(Results Submitted By User)=======================================");
            Console.WriteLine("\n\n");
          
            Console.WriteLine($"\t\t Your F- Name :  {temp.Fname}");

            Console.WriteLine($"\t\t Your M- Name : {temp.Mname}");

            Console.WriteLine($"\t\t Your L- Name: {temp.Lname}");

            Console.WriteLine($"\t\t Your 1st Adress : {temp.Fstreet}");

            Console.WriteLine($"\t\t Your 2nd Address : {temp.Sstreet}");

            Console.WriteLine($"\t\t Your City Name: {temp.City}");

            Console.WriteLine($"\t\t Zip of your Area: {temp.Zip}");

            Console.WriteLine($"\t\t Your State Name: {temp.State}");

            Console.WriteLine($"\t\t Your Cell-phone Contact:  {temp.Number}");

            Console.WriteLine($"\t\t Your Email Contact:  {temp.Email}");



            Console.ReadLine();

        }
    }
}



﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class V_list_Collection
    //=========================================================================================
    {
        //at least have an amount for every category chosen
        public static bool minimum_requirement(string temp, int atleast_amount)
        {

            bool result = false;
            if (temp.Length >= atleast_amount)
            {
                result = true;
            }
            return result;
        }

        //=========================================================================================

        public static bool Has_info(string temp)
        {

            bool result = false;
            if (temp.Length > 0)
            {
                result = true;
            }

            return result;
        }

        //=========================================================================================


        public static bool valid_number_format(string temp)
        {
            bool blnResult = false; //401-999-9999 //flip flase with true 
            int search_divider = temp.IndexOf("-");
            int second_search_divider = temp.IndexOf("-", search_divider + 1);

            if (second_search_divider >= 2)
            {
                blnResult = true;
            }


            return blnResult;

        }

        //=========================================================================================



        public static bool email_comfirm(string temp)
        {
            bool blnResult = true;
            int Look_foremail_symbol = temp.IndexOf("@");
            int secondemail_symbol = temp.IndexOf("@", Look_foremail_symbol + 1);


            int look_for_period = temp.LastIndexOf(".");

            if (Look_foremail_symbol <= 1)
            {
                blnResult = false;
            }

            else if (temp.Length < 5)
            {
                blnResult = false;
            }

            else if (look_for_period + 2 > (temp.Length))
            {
                blnResult = false;
            }

            return blnResult;

        }
    }
}
